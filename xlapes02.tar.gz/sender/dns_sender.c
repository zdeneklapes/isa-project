//
// Created by Zdeněk Lapeš on 13/10/22.
// Copyright 2022 <Zdenek Lapes>
//
// Inspiration: https://gist.github.com/fffaraz/9d9170b57791c28ccda9255b48315168

/******************************************************************************/
/**                                 TODO                                     **/
/******************************************************************************/

/******************************************************************************/
/**                                INCLUDES                                  **/
/******************************************************************************/
// #include "sender_implementation.h"
#include "../common/argument_parser.h"
#if defined(__linux__)
// https://linux.die.net/man/3/malloc_usable_size
#include <malloc.h>
size_t portable_ish_malloced_size(const void *p) { return malloc_usable_size((void *)p); }
#elif defined(__APPLE__)
// https://www.unix.com/man-page/osx/3/malloc_size/
#include <malloc/malloc.h>
size_t portable_ish_malloced_size(const void *p) { return malloc_size(p); }
#elif defined(_WIN32)
// https://learn.microsoft.com/en-us/cpp/c-runtime-library/reference/msize
#include <malloc.h>
size_t portable_ish_malloced_size(const void *p) { return _msize((void *)p); }
#else
#error "oops, I don't know this system"
#endif

size_t allocated_size(void *ptr) { return ((size_t *)ptr)[-1]; }

int main(int argc, char *argv[]) {
    // Init
    program_t *program = malloc(sizeof(program_t));
    if (program == NULL) {
        ERROR_EXIT("Failed to allocate memory for program", EXIT_FAILURE);
    }
    program->argc = argc;
    program->argv = argv;
    set_args_sender(program);                           // Validate and parse args, if failed exit
    program->dgram = init_dns_datagram(program, true);  // Validate and init dns_datagram_t, if failed exit

    // TODO: start_sending(program);
    size_t size = allocated_size(program->dgram->sender);
    (void)size;
    size = portable_ish_malloced_size(program->dgram->sender);
    DEBUG_PRINT("Size of sender: %zu\n", size);

    dealocate_all_exit(program, EXIT_SUCCESS, NULL);
}
